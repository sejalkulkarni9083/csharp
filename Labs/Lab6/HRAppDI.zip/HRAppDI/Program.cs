﻿using HR;
using HR.Services;

// Create dependency
IEmployeeService service = new EmployeeService();

// Inject dependency
HRProcessor processor = new HRProcessor(service);

// Create employees
Employee emp1 = new SalesEmployee();
Employee emp2 = new SalesManager();

// Process employees
processor.Process(emp1);
processor.Process(emp2);
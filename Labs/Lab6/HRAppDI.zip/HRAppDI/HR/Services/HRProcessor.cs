namespace HR.Services;
namespace HR.Interfaces;
public class HRProcessor{
   public readonly IEmployeeService _employeeService;

   public HRProcessor(IEmployeeService employeeService)
   {
       _employeeService = employeeService;  //constructor injection
   }

    public void Process(Employee employee)
    {
        float salary = _employeeService.GetSalary(employee);
        Console.WriteLine(employee);
        Console.WriteLine("Final Salary: " + salary);
    }
}
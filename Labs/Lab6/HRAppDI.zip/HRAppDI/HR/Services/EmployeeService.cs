
namespace HR.Interfaces;
namespace HR.Services
{
    public class EmployeeService : IEmployeeService
    {
        public float GetSalary(Employee employee)
        {
        employee.DoWork();
        return employee.ComputePay();
        }

        public void PerformDuties(Employee employee)
        {
            employee.DoWork();
             Console.WriteLine("Employee duties completed.");
        }
    }
}
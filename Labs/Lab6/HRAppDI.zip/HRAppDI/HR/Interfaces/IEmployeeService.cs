
namespace HR.Services
{
    public interface IEmployeeService
    {
        public float GetSalary(Employee employee);
        public void PerformDuties(Employee employee);
    }
}